using UnityEngine;

public class TileCell : MonoBehaviour
{
    public Vector2Int coordinates { get; set; }
    public Tile tile { get; set; }

    // Unique index for each cell, calculated based on its coordinates
    public int Index => coordinates.x * 100 + coordinates.y; // Assuming grid dimensions are less than 100

    // Fixing logic for empty and occupied
    public bool empty => tile == null;
    public bool occupied => tile != null;
}
