//TileState.cs
using System.Collections;
using UnityEngine;

[CreateAssetMenu(menuName = "Tile State")]
public class TileState : ScriptableObject
{
    public Color backgroundColor;
    public Color textColor;
    public Color color; // Property that defines the color of the tile
    public int number; // Optional: You can store the number associated with the tile state
    public bool isPoisonTile; // Set this to true for the poison tile state
}
