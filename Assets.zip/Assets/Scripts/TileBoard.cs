using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Custom Priority Queue Class
public class PriorityQueue<T>
{
    private List<(T Item, int Priority)> elements = new List<(T, int)>();

    public int Count => elements.Count;

    public void Enqueue(T item, int priority)
    {
        elements.Add((item, priority));
        elements.Sort((x, y) => x.Priority.CompareTo(y.Priority)); // Sort by priority
    }

    public T Dequeue()
    {
        if (elements.Count == 0) throw new InvalidOperationException("Priority queue is empty.");

        var item = elements[0].Item;
        elements.RemoveAt(0); // Remove the highest priority item
        return item;
    }

    public void Clear()
    {
        elements.Clear();
    }
}

public class TileBoard : MonoBehaviour
{
    public GameManager gameManager;
    public Tile tilePrefab;
    public TileState[] tileStates;
    private TileGrid grid;
    public List<Tile> tiles;
    private bool waiting;

    // HashMap for Optimized Merging
    private Dictionary<int, Tile> tileMap;

    // Custom priority queue for merging tiles based on position
    private PriorityQueue<Tile> tileQueue;

    // Spawn probability configuration
    private float probabilityForFour = 0.1f; // Initial 10% chance for a "4" tile
    private float probabilityForEight = 0.05f; // Initial 5% chance for an "8" tile

    private void Awake()
    {
        grid = GetComponentInChildren<TileGrid>();
        if (grid == null)
        {
            Debug.LogError("TileGrid is not found. Please assign a TileGrid.");
        }
        tiles = new List<Tile>(16);
        tileMap = new Dictionary<int, Tile>(16);
        tileQueue = new PriorityQueue<Tile>(); // Initialize priority queue
    }

    public void ClearBoard()
    {
        foreach (var cell in grid.cells)
        {
            cell.tile = null;
        }
        foreach (var tile in tiles)
        {
            Destroy(tile.gameObject);
        }
        tiles.Clear();
        tileMap.Clear();
    }

    public void CreateTile()
    {
        if (grid == null)
        {
            Debug.LogError("Cannot create tile: Grid is null.");
            return;
        }

        Tile tile = Instantiate(tilePrefab, grid.transform);

        // Update the logic to include 2, 4, and 8 tile values based on probabilities
        int tileValue;
        float randomValue = UnityEngine.Random.value;


        if (randomValue < probabilityForEight) // Chance to spawn 8
        {
            tileValue = 8;
        }
        else if (randomValue < probabilityForFour + probabilityForEight) // Chance to spawn 4
        {
            tileValue = 4;
        }
        else // Default to spawning 2
        {
            tileValue = 2;
        }

        tile.SetState(tileStates[tileValue == 2 ? 0 : (tileValue == 4 ? 1 : 2)], tileValue); // Update state based on tile value

        TileCell randomCell = grid.GetRandomEmptyCell();
        if (randomCell == null)
        {
            Debug.LogError("No empty cells available to spawn the tile.");
            return;
        }

        tile.Spawn(randomCell);
        tiles.Add(tile);
        tileMap[randomCell.Index] = tile; // Store tile in hash map
    }

    public void AdjustSpawnProbability(int score)
    {
        // Gradually increase the probability for spawning a "4" tile every 100 points
        probabilityForFour = Mathf.Clamp01(0.1f + (score / 1000f)); // Max probability 100%
        probabilityForEight = Mathf.Clamp01(0.05f + (score / 2000f));
    }

    private void Update()
    {
        if (!waiting)
        {
            if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            {
                ProcessMove(Vector2Int.up, 0, 1, 1, 1);
            }
            else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            {
                ProcessMove(Vector2Int.down, 0, 1, grid.Height - 2, -1);
            }
            else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                ProcessMove(Vector2Int.left, 1, 1, 0, 1);
            }
            else if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            {
                ProcessMove(Vector2Int.right, grid.Width - 2, -1, 0, 1);
            }
        }
    }

    private void ProcessMove(Vector2Int direction, int startX, int incrementX, int startY, int incrementY)
    {
        bool changed = false;

        // Enqueue all movable tiles in the priority queue based on their positions
        EnqueueMovableTiles(startX, incrementX, startY, incrementY, direction);

        while (tileQueue.Count > 0)
        {
            Tile tile = tileQueue.Dequeue();
            changed |= MoveTile(tile, direction);
        }

        if (changed)
        {
            StartCoroutine(WaitForChanges());
        }
    }

    private void EnqueueMovableTiles(int startX, int incrementX, int startY, int incrementY, Vector2Int direction)
    {
        tileQueue.Clear();

        for (int x = startX; x >= 0 && x < grid.Width; x += incrementX)
        {
            for (int y = startY; y >= 0 && y < grid.Height; y += incrementY)
            {
                TileCell cell = grid.GetCell(x, y);
                if (cell != null && cell.occupied)
                {
                    Tile tile = cell.tile;

                    // Determine priority based on the distance to the boundary
                    int priority = CalculatePriority(tile, direction);
                    tileQueue.Enqueue(tile, priority);
                }
            }
        }
    }

    private int CalculatePriority(Tile tile, Vector2Int direction)
    {
        // Priority calculation: prioritize based on distance to the boundary
        if (direction == Vector2Int.up) return tile.cell.coordinates.y;
        if (direction == Vector2Int.down) return grid.Height - tile.cell.coordinates.y - 1;
        if (direction == Vector2Int.left) return tile.cell.coordinates.x;
        return grid.Width - tile.cell.coordinates.x - 1;
    }


    private bool MoveTile(Tile tile, Vector2Int direction)
    {
        if (tile == null || tile.cell == null)
        {
            Debug.LogError("Tile or tile.cell is null.");
            return false;
        }

        TileCell newCell = null;
        TileCell adjacent = grid.GetAdjacentCell(tile.cell, direction);

        while (adjacent != null)
        {
            if (adjacent.occupied)
            {
                if (CanMerge(tile, adjacent.tile))
                {
                    Merge(tile, adjacent.tile);
                    return true;
                }
                break;
            }
            newCell = adjacent;
            adjacent = grid.GetAdjacentCell(adjacent, direction);
        }

        if (newCell != null)
        {
            tile.MoveTo(newCell);
            return true;
        }

        return false;
    }

    private bool CanMerge(Tile a, Tile b)
    {
        return a != null && b != null && a.number == b.number && !b.locked;
    }

    private void Merge(Tile a, Tile b)
    {
        tiles.Remove(a);
        tileMap.Remove(a.cell.Index); // Remove from hash map

        a.Merge(b.cell);
        int index = Mathf.Clamp(IndexOf(b.state) + 1, 0, tileStates.Length - 1);
        int number = b.number * 2;

        b.SetState(tileStates[index], number);
        tileMap[b.cell.Index] = b; // Update hash map

        gameManager.IncreaseScore(number);
    }

    private int IndexOf(TileState state)
    {
        for (int i = 0; i < tileStates.Length; i++)
        {
            if (state == tileStates[i])
            {
                return i;
            }
        }
        return -1;
    }

    private IEnumerator WaitForChanges()
    {
        waiting = true;
        yield return new WaitForSeconds(0.1f);
        waiting = false;

        foreach (var tile in tiles)
        {
            tile.locked = false;
        }

        if (tiles.Count != grid.Size)
        {
            CreateTile();
        }
        if (CheckForGameOver())
        {
            gameManager.GameOver();
        }
    }

    private bool CheckForGameOver()
    {
        if (tiles.Count != grid.Size)
        {
            return false;
        }
        foreach (var tile in tiles)
        {
            TileCell up = grid.GetAdjacentCell(tile.cell, Vector2Int.up);
            TileCell down = grid.GetAdjacentCell(tile.cell, Vector2Int.down);
            TileCell left = grid.GetAdjacentCell(tile.cell, Vector2Int.left);
            TileCell right = grid.GetAdjacentCell(tile.cell, Vector2Int.right);

            if (up != null && CanMerge(tile, up.tile))
            {
                return false;
            }
            if (down != null && CanMerge(tile, down.tile))
            {
                return false;
            }
            if (left != null && CanMerge(tile, left.tile))
            {
                return false;
            }
            if (right != null && CanMerge(tile, right.tile))
            {
                return false;
            }
        }
        return true;
    }
}
